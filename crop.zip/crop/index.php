<?php
/*
Gary George 2013
http://www.georgewebdesign.co.uk
@gary_george
http://youtube.com/user/GeorgeWebDesign


To use the below code you just have to change all paths to be relative to your server.

NOTE: you will need a PHP enabled server with GD Support enabled for this to work.
*/

//profile id
	$profile_id = 12345;


/***********************************************************
	0 - Remove The Temp image if it exists
***********************************************************/
	if (!isset($_POST['x']) && !isset($_FILES['image']['name']) ){
		//Delete users temp image
			$temppath = 'images/'.$profile_id.'_temp.jpeg';
			if (file_exists ($temppath)){ @unlink($temppath); }
	} 


if(isset($_FILES['image']['name'])){	
	/***********************************************************
		1 - Upload Original Image To Server
	***********************************************************/	
		//Get Name | Size | Temp Location		    
			$ImageName = $_FILES['image']['name'];
			$ImageSize = $_FILES['image']['size'];
			$ImageTempName = $_FILES['image']['tmp_name'];
		//Get File Ext   
			$ImageType = @explode('/', $_FILES['image']['type']);
			$type = $ImageType[1]; //file type	
		//Set Upload directory    
			$uploaddir = $_SERVER['DOCUMENT_ROOT'].'/tutorials/images';
		//Set File name	
			$file_temp_name = $profile_id.'_original.'.md5(time()).'n'.$type; //the temp file name
			$fullpath = "$uploaddir/".$file_temp_name; // the temp file path
			$file_name = $profile_id.'_temp.jpeg'; //$profile_id.'_temp.'.$type; // for the final resized image
			$fullpath_2 = "$uploaddir/".$file_name; //for the final resized image
		//Move the file to correct location
			$move = move_uploaded_file($ImageTempName ,$fullpath) ; 
			chmod($fullpath, 0777);  
   		//Check for valid uplaod
			if (!$move) { 
				die ('File didnt upload');
			} else { 
				$imgSrc= 'http://georgewebdesign.co.uk/tutorials/images/'.$file_name.'?x='.rand(); // the image to display in crop area
				$msg= "Upload Complete!";  	//message to page
				$src = $file_name;	 		//the file name to post from cropping form to the resize		
			} 

	/***********************************************************
		2  - Resize The Image To Fit In Cropping Area
	***********************************************************/		
			//get the uploaded image size	
				clearstatcache();				
				$original_size = getimagesize($fullpath);
				$original_width = $original_size[0];
				$original_height = $original_size[1];	
			// Specify The new size
				$main_width = 500; // set the width of the image
				$main_height = $original_height / ($original_width / $main_width);	// this sets the height in ratio									
			//create new image using correct php func			
				if($_FILES["image"]["type"] == "image/gif"){
					$src2 = imagecreatefromgif($fullpath);
				}elseif($_FILES["image"]["type"] == "image/jpeg" || $_FILES["image"]["type"] == "image/pjpeg"){
					$src2 = imagecreatefromjpeg($fullpath);
				}elseif($_FILES["image"]["type"] == "image/png"){ 
					$src2 = imagecreatefrompng($fullpath);
				}else{ 
					$msg .= "There was an error uploading the file. Please upload a .jpg, .gif or .png file. <br />";
				}
			//create the new resized image
				$main = imagecreatetruecolor($main_width,$main_height);
				imagecopyresampled($main,$src2,0, 0, 0, 0,$main_width,$main_height,$original_width,$original_height);
			//upload new version
				$main_temp = $fullpath_2;
				imagejpeg($main, $main_temp, 90);
				chmod($main_temp,0777);
			//free up memory
				imagedestroy($src2);
				imagedestroy($main);
				imagedestroy($fullpath);
				@ unlink($fullpath); // delete the original upload					
									
}//ADD Image 	

	


/***********************************************************
	3- Cropping & Converting The Image To Jpg
***********************************************************/
	if ($_POST['x']){
		
		//the file type posted
			$type = $_POST['type'];	
		//the image src
			$src = 'images/'.$_POST['src'];	
			$finalname = md5(time());	
		
		if($type == 'jpg' || $type == 'jpeg' || $type == 'JPG' || $type == 'JPEG'){	
		
			//the target dimensions 150x150
				$targ_w = $targ_h = 150;
			//quality of the output
				$jpeg_quality = 90;
			//create a cropped copy of the image
				$img_r = imagecreatefromjpeg($src);
				$dst_r = imagecreatetruecolor( $targ_w, $targ_h );
				imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
				$targ_w,$targ_h,$_POST['w'],$_POST['h']);
			//save the new cropped version
				imagejpeg($dst_r, "images/".$finalname."n.jpeg", 90); 	
				 		
		}else if($type == 'png' || $type == 'PNG'){
			
			//the target dimensions 150x150
				$targ_w = $targ_h = 150;
			//quality of the output
				$jpeg_quality = 90;
			//create a cropped copy of the image
				$img_r = imagecreatefrompng($src);
				$dst_r = imagecreatetruecolor( $targ_w, $targ_h );		
				imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
				$targ_w,$targ_h,$_POST['w'],$_POST['h']);
			//save the new cropped version
				imagejpeg($dst_r, "images/".$finalname."n.jpeg", 90); 	
							
		}else if($type == 'gif' || $type == 'GIF'){
			
			//the target dimensions 150x150
				$targ_w = $targ_h = 150;
			//quality of the output
				$jpeg_quality = 90;
			//create a cropped copy of the image
				$img_r = imagecreatefromgif($src);
				$dst_r = imagecreatetruecolor( $targ_w, $targ_h );		
				imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
				$targ_w,$targ_h,$_POST['w'],$_POST['h']);
			//save the new cropped version
				imagejpeg($dst_r, "images/".$finalname."n.jpeg", 90); 	
			
		}
			//free up memory
				imagedestroy($img_r); // free up memory
				imagedestroy($dst_r); //free up memory
				@ unlink($src); // delete the original upload					
			
			//return cropped image to page	
			$displayname ="images/".$finalname."n.jpeg";
															
	}// post x



	
	

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>GeorgeWebDesign | PHP Custom Image Crop Tutorial</title>

<style>
	body{ background-color:#666666; padding:0px; margin:0px;}
	#formExample{ position:relative; margin:100px auto; width:200px; min-height:200px;}
	p { font:16px sans-serif; color:#990000;}
</style>

<script src="js/jquery.min.js"></script>
<script src="js/jquery.Jcrop.min.js"></script>
<link rel="stylesheet" href="css/jquery.Jcrop.css" type="text/css" />

<script>
 
//JCrop Bits
  $(function(){
	  
    $('#jcrop_target').Jcrop({
      aspectRatio: 1,
	  setSelect:   [ 200,200,37,49 ],
      onSelect: updateCoords
    });

  });

  function updateCoords(c)
  {
    $('#x').val(c.x);
    $('#y').val(c.y);
    $('#w').val(c.w);
    $('#h').val(c.h);
  };

  function checkCoords()
  {
    if (parseInt($('#w').val())) return true;
    alert('Please select a crop region then press submit.');
    return false;
  }; 
//End JCrop Bits

	function cancelCrop(){
		//Refresh page				
		top.location = 'index.php?cancel';
		return false;
	}

</script>
</head>

<body>

<div id="Overlay" style=" width:100%; height:100%; background-color:rgba(0,0,0,.5); border:0px #990000 solid; position:absolute; top:0px; left:0px; z-index:2000; display:none;"></div>


<div id="wrapper" style="width:1000px; min-height:600px; position:relative; margin:0px auto; border:1px #444 solid; background-color:#EFEFEF;">


<div id="formExample">
	
    <p><b> <?=$msg?> </b></p>
    
    <form action="index" method="post"  enctype="multipart/form-data">
        Upload something<br /><br />
        <input type="file" id="image" name="image" style="width:200px; height:30px; background-color:#FFFFFF;" /><br /><br />
        <input type="submit" value="submit" style="width:85px; height:25px;" />
    
    </form><br /><br />
    
</div> <!-- Form-->  




    <?php  if($imgSrc){ //if an image has been uploaded display cropping area?>
    <script>
    	$('#Overlay').show();
		$('#formExample').hide();
    </script>
    <div id="CroppingContainer" style="width:800px; max-height:600px; background-color:#FFF; position:relative; overflow:hidden; border:2px #666 solid; margin:50px auto; z-index:2001; padding-bottom:0px;">  
    
        <div id="CroppingArea" style="width:500px; max-height:400px; position:relative; overflow:hidden; margin:40px 0px 40px 40px; border:2px #666 solid; float:left;">	
            <img src="<?=$imgSrc?>" border="0" id="jcrop_target" style="border:0px #990000 solid; position:relative; margin:0px 0px 0px 0px; padding:0px; " />
        </div>  
        <div id="InfoArea" style="width:180px; height:150px; position:relative; overflow:hidden; margin:40px 0px 0px 40px; border:0px #666 solid; float:left;">	
           <p style="margin:0px; padding:0px; color:#444; font-size:18px;">          
                <b>Crop Profile Image</b><br /><br />
                <span style="font-size:14px;">
                    Using this tool crop / resize your uploaded profile image. <br />
                    Once you are happy with your profile image then please click save.
                </span>
           </p>
        </div>  
        <br />
            <div id="CropImageForm" style="width:100px; height:30px; float:left; margin:10px 0px 0px 40px;" >  
                <form action="index" method="post" onsubmit="return checkCoords();">
                    <input type="hidden" id="x" name="x" />
                    <input type="hidden" id="y" name="y" />
                    <input type="hidden" id="w" name="w" />
                    <input type="hidden" id="h" name="h" />
                    <input type="hidden" value="jpeg" name="type" /> <?php // $type ?> 
                    <input type="hidden" value="<?=$src?>" name="src" />
                    <input type="submit" value="Crop Image" style="width:100px; height:30px;"   />
                </form>
            </div>
            <div id="CropImageForm2" style="width:100px; height:30px; float:left; margin:10px 0px 0px 40px;" >  
                <form action="index" method="post" onsubmit="return cancelCrop();">
                    <input type="submit" value="Cancel Crop" style="width:100px; height:30px;"   />
                </form>
            </div>            
            
    </div><!-- CroppingContainer -->
	<?php } ?>
 
 
 
 
 
 <?php if($displayname) {
	 ?>
     
     <img src="<?=$displayname?>" style="position:relative; margin:10px auto; width:150px; height:150px;" />
	 
 <?php } ?>
 
 
    <br /><br />
</div>


    
</body>
</html>
